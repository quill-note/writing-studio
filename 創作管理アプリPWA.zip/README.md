# 創作管理アプリ (クリエイティブアプリ01)

創作用の登場人物・コンテスト・辞書管理PWAアプリです。

## 機能
- 登場人物リスト管理（作品別、フィルター対応）
- コンテスト提出・結果管理
- 表現辞書（タグ分類対応）
- JSONバックアップ・復元
- オフライン対応（PWA）

## セットアップ手順

### 1. ファイルをGitHubにアップロード

以下のファイルをリポジトリに配置してください：

```
creative-app01/
├── index.html      ← メインアプリ
├── manifest.json   ← PWA設定
├── sw.js           ← Service Worker
├── README.md       ← このファイル
└── icons/
    ├── icon-192x192.png
    └── icon-512x512.png
```

### 2. GitHub Pagesを有効にする

1. GitHubのリポジトリページを開く
2. 右下の **⚙ Settings**（歯車アイコン）をタップ
3. 左メニューの **Pages** をタップ
4. 「Source」で **Deploy from a branch** を選択
5. Branch を **main** 、フォルダを **/ (root)** に設定
6. **Save** をタップ
7. 数分待つとURLが発行されます

### 3. アプリにアクセス

`https://hikahikahika01.github.io/creative-app01/` でアクセスできます。

### 4. ホーム画面に追加

- **Android**: Chromeでアクセス → メニュー（⋮）→「ホーム画面に追加」
- **iPhone**: Safariでアクセス → 共有ボタン →「ホーム画面に追加」
